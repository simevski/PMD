//----------------------------------------------------------------------------
// Design units     : int_addr
// File name        : int_addr.h
// Purpose          : Addresses of internal (on-chip) peripherals
// Note             : 
// Limitations      : 
// Errors           : 
// Dependencies     : 
// Author           : A.S.
//                    IHP GmbH, System Design Department
//                    simevski@ihp-microelectronics.com
//
// Revision list
//   Version        : 1.0
//   Author         : A.S.
//   Last modified  : 2017-11-17
//   Changes        : new version
//----------------------------------------------------------------------------

//Core implementation register
#define CORE_IMPL_BASE 0x10000000

//IRQ controller
#define IRQ_CNTRL_BASE 0x10001000
#define IRQ_ENABLE     0x00
#define IRQ_LVLSENS    0x04
#define IRQ_POSTPONE   0x08
#define IRQ_PENDING    0x0C
#define IRQ_ACK        0x10
#define IRQ_SWIRQ      0x14
#define IRQ_SET        0x18
#define IRQ_RESET      0x1C

//MMU
#define ITLB_CNTRL_BASE 0x10002000
#define DTLB_CNTRL_BASE 0x10003000
#define TLB_CNTRL       0x8
#define TLB_PTE(x)      16*x

//Caches
#define ICACHE_CNTRL_BASE  0x10004000
#define DCACHE_CNTRL_BASE  0x10005000
#define L1CACHE_CNTRL_BASE 0x10006000
#define L2CACHE_CNTRL_BASE 0x10007000
#define L3CACHE_CNTRL_BASE 0x10008000

//Timers
#define SYSTEM_TIMER_BASE  0x10009000
#define USER_TIMER_BASE    0x1000A000
#define TIMER_CNTRL        0x0
#define TIMER_RELOAD       0x4
#define TIMER_REG          0x8
#define TIMER_TIMOUT       0xC

//Waterbear Framework Controller (WFC) (one level higher):
#define WFC_ADDR_BASE      0x17FFC000
#define WFC_ADDRREG        0x000
#define WFC_CR0            0x008
#define WFC_CR_POWOFF      0x108
#define WFC_CR_CLKOFF      0x208
#define WFC_CR_RSTM        0x308
#define WFC_CR_IRQ         0x408
#define WFC_CR_FTG         0x508
#define WFC_CR_RSTERRCNT   0x608
#define WFC_CR_INITAGERD   0x708
#define WFC_ACT(x)         0x010+x*256
#define WFC_HCIMON(x)      0x018+x*256
#define WFC_NBTIMON(x)     0x020+x*256
#define WFC_LASTACT        0x028
#define WFC_ERRCNT(x)      0x030+x*256

