//----------------------------------------------------------------------------
// Design units     : 
// File name        : mccommon.S
// Purpose          : Common multicore functions
// Note             : 
// Limitations      : 
// Errors           : 
// Dependencies     : 
// Author           : A.S.
//                    IHP GmbH, System Design Department
//                    simevski@ihp-microelectronics.com
//
// Revision list
//   Version        : 1.0
//   Author         : A.S.
//   Last modified  : 2019-02-20
//   Changes        : new version
//----------------------------------------------------------------------------

#define NR_CORES 4

#define _TRAN_CORE_TO(x)   limm r2, 1; \
									sl r2, r1; \
									and r2, r0; \
									tb r2, r1; \
									bnz r2, x; \
									incr r1

#define _TRAN_CORES  limm r0, 1; \
							copy r1, cid; \
							sl r0, r1; \
							limm r1, 0; \
							_TRAN_CORE_TO(_prog4core0); \
							_TRAN_CORE_TO(_prog4core1); \
							_TRAN_CORE_TO(_prog4core2); \
							_TRAN_CORE_TO(_prog4core3);

#define _UNICID   limm reg0, 0; \
						limm reg1, _COMMON_ADDR_; \
						stor reg1[0], reg0; \
						sync; \
						load reg0, reg1[0]; \
						copy CID, reg0; \
						incr reg0; \
						stor reg1[0], reg0; \
						csyn; \
						jmp 2; \
						.wvar _COMMON_ADDR_ 0 //ignore warning (for not in .data sec)

