//----------------------------------------------------------------------------
// Design units     : BubbleSort
// File name        : sort.c
// Purpose          : Example program
// Note             : 
// Limitations      : 
// Errors           : 
// Dependencies     : 
// Author           : A.S.
//                    IHP GmbH, System Design Department
//                    simevski@ihp-microelectronics.com
//
// Revision list
//   Version        : 1.0
//   Author         : A.S.
//   Last modified  : 2018-11-15
//   Changes        : new version
//----------------------------------------------------------------------------

void BubbleSort(int [], int);
int a = {1, 3, 6, 7, 1, 2};

int main()
{
	BubbleSort(a, 5);
}

void BubbleSort(int a[], int array_size)
{
    int i, j, temp;
    for (i = 0; i < (array_size - 1); ++i)
    {
        for (j = 0; j < array_size - 1 - i; ++j )
        {
            if (a[j] > a[j+1])
            {
                temp = a[j+1];
                a[j+1] = a[j];
                a[j] = temp;
            }
        }
    }
}

