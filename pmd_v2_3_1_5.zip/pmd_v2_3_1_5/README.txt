Peaktop Multiprocessor Debugger (PMD)
(c) 2012-2021, Igor Simevski

INSTALLATION
=============

Installation can be:
  1. Automatic
  2. Manual
provided that the necessary read/write/execute accesses are granted.

1. Prerequisites
-----------------
- Linux or Mac OS distribution is required.
- A perl installation is required with /lib64/libc.so.6: version 'GLIBC_2.14'.
- The perl-tk package is required.
- A PDF Document Viewer (evince) or Acrobat Reader (acroread) is required.
- libterm-readline-gnu-perl (term::readline::gnu) and
  libtk-splashscreen-perl are good to have.

2. Automatic installation
--------------------------
 a) Execute the 'install' script within this folder;
    the script requires quoting the path to the INSTALL_DIR (installation
    directory) in which the installation will be placed. It can be also given
    as an argument.

3. Manual installation
--------------------------
 a) Copy the folder containing this file in the INSTALL_DIR;
 b) Copy the config/peaktop.config file (in this folder) to ~/.config/peaktop/
 c) Copy the config/pmd.config file (in this folder) to ~/.config/pmd/

4. Environment variables
----------------------------
For both types of installation add the environment variable PMD_INSTALL_DIR
with a value of the path to the installation directory, e.g.,

   PMD_INSTALL_DIR=/INSTALL/DIR/pas_vX_X_X_X

If the GCC compiler is to be used, add the environment variable PEAKTOP_GCC
with a value of the path to the GCC executable.

Put these directories also in the executable path, i.e., in the $PATH
environment variable.

5. PEAKTOP syntax highlighter
------------------------------
The installation package contains an XML syntax highlighter
'peaktop_assembly.lang' for the PEAKTOP assembly language. You can copy it,
e.g., in /usr/share/gtksourceview-2.0/language-specs/

6. Uninstallation
------------------
Just delete folder /INSTALL/DIR/pas_vX_X_X_X and delete the PMD_INSTALL_DIR
environment variable. Delete also the folders ~/.config/peaktop and
~/.config/pmd
